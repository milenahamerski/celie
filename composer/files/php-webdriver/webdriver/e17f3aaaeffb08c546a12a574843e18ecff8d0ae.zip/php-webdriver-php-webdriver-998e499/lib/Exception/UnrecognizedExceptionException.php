<?php

namespace Facebook\WebDriver\Exception;

class UnrecognizedExceptionException extends WebDriverException
{
}
