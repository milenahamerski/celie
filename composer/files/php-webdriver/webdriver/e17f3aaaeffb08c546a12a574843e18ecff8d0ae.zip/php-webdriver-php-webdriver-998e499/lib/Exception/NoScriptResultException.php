<?php

namespace Facebook\WebDriver\Exception;

/**
 * @deprecated Removed in W3C WebDriver, see https://github.com/php-webdriver/php-webdriver/pull/686
 */
class NoScriptResultException extends WebDriverException
{
}
