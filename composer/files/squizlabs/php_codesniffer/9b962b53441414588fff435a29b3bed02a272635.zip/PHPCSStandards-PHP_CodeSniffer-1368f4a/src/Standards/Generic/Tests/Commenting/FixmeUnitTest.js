
/**
 * FIXME: Write this comment
 * FIXME
 */

// FIXME: remove this.
alert('test');

// FIXME remove this.
alert('test');

// fixme - remove this.

// Extract info from the array.
// FIXME: can this be done faster?

// Extract info from the array (fixme: make it faster)
// To do this, use a function!
// nofixme! NOFIXME! NOfixme!
//FIXME.
//éfixme
//fixmeé
